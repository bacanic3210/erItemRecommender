package erItemRecommend;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class Recommender {
	Connection con = null;
	Statement st = null;
	ResultSet result = null;
	Scanner sc = new Scanner(System.in);

	public void run() {
		dbInit();
		loop: while (true) {
			System.out.println("1. 아이템 추가  2. 아이템 목록   3. 아이템 추천  4. 아이템 삭제  x.종료");
			System.out.print("명령 입력 : ");
			String cmd = sc.next();
			switch (cmd) {
			case "1":
				sc.nextLine();
				System.out.print("아이템 이름 입력 : ");
				String itemName = sc.nextLine();

				String itemPart = null;
				while (true) {
					System.out.print("아이템 부위(상의, 모자, 팔, 다리) 입력 : ");
					itemPart = sc.next();
					if (itemPart.equals("상의") || itemPart.equals("모자") || itemPart.equals("팔")
							|| itemPart.equals("다리")) {
						break;
					} else {
						System.out.println("잘못된 입력입니다.");
					}
				}
				System.out.print("공격력 : ");
				int itematk = sc.nextInt();
				System.out.print("공격속도 : ");
				int itematksp = sc.nextInt();
				System.out.print("스킬증폭 : ");
				int itemap = sc.nextInt();
				System.out.print("체력 : ");
				int itemhp = sc.nextInt();
				System.out.print("방어력 : ");
				int itemdef = sc.nextInt();
				System.out.print("쿨타임 감소 : ");
				int itemcool = sc.nextInt();
				System.out.print("치명타 확률 : ");
				int itemcrit = sc.nextInt();

				try {
					st.executeUpdate(
							"insert into er_items (item_name, atk, atkspeed, ap, hp, def, cooldown, crit, item_part) values ('"
									+ itemName + "','" + itematk + "','" + itematksp + "','" + itemap + "','" + itemhp
									+ "','" + itemdef + "','" + itemcool + "','" + itemcrit + "','" + itemPart + "')");
					System.out.println("아이템 등록 완료");
				} catch (SQLException e) {
					e.printStackTrace();
				}
				// 아이템 추가
				break;
			case "2":
				try {
					String str = String.format("%-12s%-12s%-8s%-8s%-8s%-8s%-8s%-8s%-10s", "아이템 이름", "아이템 부위", "공격력",
							"공격속도", "스킬증폭", "체력", "방어력", "쿨타임감소", "크리티컬확률");
					System.out.println(str);
					String sql = "select * from er_items";
					result = st.executeQuery(sql);
					while (result.next()) {
						String it_Name = result.getString("item_name");
						String it_Part = result.getString("item_part");
						int it_atk = result.getInt("atk");
						int it_atksp = result.getInt("atkspeed");
						int it_ap = result.getInt("ap");
						int it_hp = result.getInt("hp");
						int it_def = result.getInt("def");
						int it_cooldown = result.getInt("cooldown");
						int it_crit = result.getInt("crit");

						String str1 = String.format("%-12s%-12s%-10d%-10d%-10d%-10d%-10d%-10d%-12d", it_Name, it_Part,
								it_atk, it_atksp, it_ap, it_hp, it_def, it_cooldown, it_crit);
						System.out.println(str1);
//						System.out.println(it_Name + " " + it_Part + " " + it_atk + " " + it_atksp + " "
//								+ it_ap + " " + it_hp + " " + it_def + " " + it_cooldown + " " + it_crit);
					}
				} catch (SQLException e) {
					e.printStackTrace();
				}

				// 아이템 리스트 쭉 뽑기
				break;
			case "3":
				System.out.print("최우선 스탯을 입력하세요(atk, as, ap, hp, def, cd, cri): ");
				String stat1 = sc.next();
				System.out.print("두번째 스탯을 입력하세요(atk, as, ap, hp, def, cd, cri): ");
				String stat2 = sc.next();
				System.out.print("세번째 스탯을 입력하세요(atk, as, ap, hp, def, cd, cri): ");
				String stat3 = sc.next();
				
				cal_score(stat1,stat2,stat3);
				break;
			// 3순위까지 스탯 입력받아 점수 합산해서 높은순으로 찍어주기
			case "4":
				sc.nextLine();
				try {
					String sql2 = "select item_name from er_items";
					result = st.executeQuery(sql2);
					while (result.next()) {
						String it_Name = result.getString("item_name");
						System.out.println(it_Name);
					}
				} catch (SQLException e) {
					e.printStackTrace();
				}
				System.out.print("삭제할 아이템의 이름을 입력하세요: ");
				String delItemName = sc.nextLine();
				try {
					st.executeUpdate("delete from er_items where item_name='" + delItemName + "'");
				} catch (SQLException e) {
					e.printStackTrace();
				}
				break;
			case "x":
				System.out.println("프로그램 종료");
				break loop;
			}
		}
	}

	public void dbInit() {
		try {
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/my_cat", "root", "root");
			st = con.createStatement();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public void cal_score(String stat1, String stat2, String stat3) {
		String sql_stat1 = toSqlStat(stat1);
		String sql_stat2 = toSqlStat(stat2);
		String sql_stat3 = toSqlStat(stat3);
		
		// 그 max에 대해서 하나 하나 계산해 가장 높은 점수의 item_num 추출하기

//		String Sql = "select MAX(" + sql_stat1 + ") from er_items";
//		try {
//			result = st.executeQuery(Sql);
//			result.next();
//			max_stat1 = result.getInt("MAX(" + sql_stat1 + ")");
//		} catch (SQLException e) {
//			e.printStackTrace();
//		}
//		Sql = "select MAX(" + sql_stat2 + ") from er_items";
//		try {
//			result = st.executeQuery(Sql);
//			result.next();
//			max_stat2 = result.getInt("MAX(" + sql_stat2 + ")");
//		} catch (SQLException e) {
//			e.printStackTrace();
//		}
//		Sql = "select MAX(" + sql_stat3 + ") from er_items";
//		try {
//			result = st.executeQuery(Sql);
//			result.next();
//			max_stat3 = result.getInt("MAX(" + sql_stat3 + ")");
//		} catch (SQLException e) {
//			e.printStackTrace();
//		}
		
//		float max_score = 0;
//		int max_itemnum = 0;
//		Sql = "select * from er_items where item_part = '상의'";
//		try {
//			result = st.executeQuery(Sql);
//			while(result.next()) {
//				float cur_score = 0;
//				cur_score += (result.getInt(sql_stat1) / max_stat1) * 100;
//				cur_score += (result.getInt(sql_stat2) / max_stat2) * 100;
//				cur_score += (result.getInt(sql_stat3) / max_stat3) * 100;
//				
//				if(cur_score > max_score) {
//					max_score = cur_score;
//					max_itemnum = result.getInt("item_num");
//				}
//			}
//		} catch(SQLException e) {
//			e.printStackTrace();
//		}
//		
//		Sql = "select * from er_items where item_num = " + max_itemnum;
//		try {
//			result = st.executeQuery(Sql);
//			result.next();
//			System.out.print(result.getString("item_name"));
//		} catch(SQLException e) {
//			e.printStackTrace();
//		} 함수 따로 뺌

		System.out.println("상의 : " + getSqlItem("상의", sql_stat1, sql_stat2, sql_stat3));
		System.out.println("모자 : " + getSqlItem("모자", sql_stat1, sql_stat2, sql_stat3));
		System.out.println("팔/장식 : " + getSqlItem("팔", sql_stat1, sql_stat2, sql_stat3));
		System.out.println("다리 : " + getSqlItem("다리", sql_stat1, sql_stat2, sql_stat3));
	}

	public String toSqlStat(String n) {
		switch (n) {
		case "atk":
			return "atk";
		case "as":
			return "atkspeed";
		case "ap":
			return "ap";
		case "hp":
			return "hp";
		case "def":
			return "def";
		case "cd":
			return "cooldown";
		case "cri":
			return "crit";
		}
		return "오류";
	}
	
	public String getSqlItem(String itemPart, String sql_stat1, String sql_stat2, String sql_stat3) {
		int max_stat1 = 0, max_stat2 = 0, max_stat3 = 0;
		String Sql = "select MAX(" + sql_stat1 + ") from er_items where item_part = '" + itemPart + "'";
		try {
			result = st.executeQuery(Sql);
			result.next();
			max_stat1 = result.getInt("MAX(" + sql_stat1 + ")");
		} catch (SQLException e) {
			e.printStackTrace();
		}
		Sql = "select MAX(" + sql_stat2 + ") from er_items where item_part = '" + itemPart + "'";
		try {
			result = st.executeQuery(Sql);
			result.next();
			max_stat2 = result.getInt("MAX(" + sql_stat2 + ")");
		} catch (SQLException e) {
			e.printStackTrace();
		}
		Sql = "select MAX(" + sql_stat3 + ") from er_items where item_part = '" + itemPart + "'";
		try {
			result = st.executeQuery(Sql);
			result.next();
			max_stat3 = result.getInt("MAX(" + sql_stat3 + ")");
		} catch (SQLException e) {
			e.printStackTrace();
		} //각 스탯에 대해 최댓값 빼내기
		
		float max_score = 0;
		int max_itemnum = 0;
		Sql = "select * from er_items where item_part = '" + itemPart + "';";
		try {
			result = st.executeQuery(Sql);
			while(result.next()) {
				float cur_score = 0;
				cur_score += (result.getInt(sql_stat1) / max_stat1) * 100;
				cur_score += ((result.getInt(sql_stat2) / max_stat2)*0.8) * 100; //빼낸 최댓값을 100점만점으로 두고 각 아이템에 스탯에 대해 점수 계산
				cur_score += ((result.getInt(sql_stat3) / max_stat3)*0.5) * 100; //스탯 우선순위따라 가중치 부여
				
				if(cur_score > max_score) {
					max_score = cur_score;
					max_itemnum = result.getInt("item_num"); //최고 점수 아이템 item_num 빼서 저장
				}
			}
		} catch(SQLException e) {
			e.printStackTrace();
		}
		
		Sql = "select * from er_items where item_num = " + max_itemnum; //빼놓은 item_num으로 가장 적절한 아이템 찾기
		String bestItem = "";
		try {
			result = st.executeQuery(Sql);
			result.next();
			bestItem = result.getString("item_name");
		} catch(SQLException e) {
			e.printStackTrace();
		}
		return bestItem;
	}
}
