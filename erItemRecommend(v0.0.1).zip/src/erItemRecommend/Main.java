package erItemRecommend;



public class Main {
	public static void main(String[] args) {
		Recommender rec = new Recommender();
		rec.run();
	}

}
